package com.randhypi.githubuserapp.vm

import org.junit.Test

class MainViewModelTest {

    @Test
    fun getUserAll() {

    }
}